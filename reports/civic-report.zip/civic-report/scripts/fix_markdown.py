#!/usr/bin/env python3
"""Fix two common markdown issues that the Python-Markdown renderer
mishandles silently:

  1. Bullet lists with no blank line before the first bullet — these
     render as paragraphs with literal "- " text instead of as lists.
     Insert a blank line before the start of each list (but not between
     sibling bullets in the same list).

  2. Bare URLs not wrapped in markdown link syntax — these render as
     plain text instead of clickable links. Convert each bare URL to
     [shortened-anchor](full-url) form, where the anchor text is a
     friendly shortened version like "domain.com/.../filename".

Both fixes are idempotent — running this script twice produces the same
result as running it once.

Usage:
    python3 fix_markdown.py input.md            # in-place
    python3 fix_markdown.py input.md output.md  # to new file

Run this AFTER apply_conventions.py.
"""

import re
import sys
from pathlib import Path


def is_bullet(line: str) -> bool:
    """Does this line start with a bullet marker?"""
    return bool(re.match(r"^\s*-\s", line))


def is_indented(line: str, min_indent: int = 2) -> bool:
    """Is this line indented at least `min_indent` spaces (and not blank)?"""
    if not line.strip():
        return False
    leading = len(line) - len(line.lstrip(" "))
    return leading >= min_indent


def fix_bullet_blank_lines(text: str) -> tuple[str, int]:
    """Insert a blank line before the first bullet of each list (but not
    between sibling bullets). Returns (new_text, n_inserted)."""
    lines = text.split("\n")
    new_lines: list[str] = []
    n_inserted = 0
    for line in lines:
        if is_bullet(line):
            # Find the previous non-blank line in new_lines
            j = len(new_lines) - 1
            while j >= 0 and not new_lines[j].strip():
                j -= 1
            if j >= 0:
                prev = new_lines[j]
                # If the previous non-blank line is a bullet or a
                # continuation of one (indented), this bullet is a sibling —
                # no blank line needed.
                if not is_bullet(prev) and not is_indented(prev):
                    # Need a blank line before this list start.
                    if new_lines and new_lines[-1].strip() != "":
                        new_lines.append("")
                        n_inserted += 1
        new_lines.append(line)
    return "\n".join(new_lines), n_inserted


def shorten_url(url: str) -> str:
    """Make a friendly short anchor text from a URL.

    Examples:
        https://hebronct.com/uploads/2014/03/budget-book.pdf
            → hebronct.com/.../budget-book.pdf
        https://example.org/page
            → example.org/page
        https://example.org
            → example.org
    """
    m = re.match(r"https?://([^/]+)(/.*)?", url)
    if not m:
        return url
    domain = m.group(1).lower()
    if domain.startswith("www."):
        domain = domain[4:]
    path = m.group(2) or ""
    # Strip query string and fragment for the anchor text
    path = path.split("?")[0].split("#")[0]
    if path.endswith("/"):
        path = path[:-1]
    if not path:
        return domain
    last_seg = path.rsplit("/", 1)[-1]
    if not last_seg:
        return domain
    if path.count("/") > 1:
        return f"{domain}/.../{last_seg}"
    return f"{domain}{path}"


# Match bare URLs not preceded by `(`, `[`, or `<` (which would mean
# they're already inside markdown/HTML link syntax) and not followed by
# `)`, `]`, or `>` (same).
URL_RE = re.compile(r'(?<![\(\[<])(https?://[^\s\)\]<>"]+)(?![\)\]>])')


def convert_bare_urls(text: str) -> tuple[str, int]:
    """Convert bare URLs to markdown links with friendly anchor text.
    Skips fenced code blocks and indented code blocks. Returns
    (new_text, n_converted)."""

    def repl(m):
        url = m.group(1)
        # Strip trailing sentence punctuation that's likely not part of
        # the URL itself
        trailing = ""
        while url and url[-1] in ".,;:":
            trailing = url[-1] + trailing
            url = url[:-1]
        anchor = shorten_url(url)
        return f"[{anchor}]({url}){trailing}"

    out_lines = []
    in_code_fence = False
    n_converted = 0
    for line in text.split("\n"):
        if line.strip().startswith("```"):
            in_code_fence = not in_code_fence
            out_lines.append(line)
            continue
        if in_code_fence:
            out_lines.append(line)
            continue
        # Skip indented code blocks (4+ leading spaces)
        if line.startswith("    ") and line.strip():
            out_lines.append(line)
            continue
        n_converted += len(URL_RE.findall(line))
        out_lines.append(URL_RE.sub(repl, line))

    return "\n".join(out_lines), n_converted


def main():
    if len(sys.argv) < 2 or len(sys.argv) > 3:
        print("Usage: python3 fix_markdown.py input.md [output.md]",
              file=sys.stderr)
        sys.exit(2)

    in_path = Path(sys.argv[1])
    out_path = Path(sys.argv[2]) if len(sys.argv) == 3 else in_path

    text = in_path.read_text(encoding="utf-8")
    original_len = len(text)

    text, n_blanks = fix_bullet_blank_lines(text)
    text, n_urls = convert_bare_urls(text)

    out_path.write_text(text, encoding="utf-8")
    print(f"Wrote {out_path} ({len(text):,} chars, "
          f"{len(text.splitlines())} lines, {len(text) - original_len:+d} chars)")
    print(f"  - Inserted {n_blanks} blank lines before list starts")
    print(f"  - Converted {n_urls} bare URLs to markdown links")


if __name__ == "__main__":
    main()
