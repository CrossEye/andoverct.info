#!/usr/bin/env python3
"""Apply civic-report markdown conventions to a markdown file:

  1. Setext headers (=== / ---) for H1/H2.
  2. Symmetric ATX style ("### Foo ###") for H3+.
  3. Indent nested bullets 2 spaces per level (no-op if no nested bullets).
  4. Blank lines: >=3 before H2, >=2 before H3+, except first child.
  5. Single blank line after every header.
  6. Align table column markers unless line >150 chars.
  7. Wrap prose at 80 chars; exceptions: code, table markup, lines with
     unwrappable tokens (e.g. long URLs).

This script does NOT change content -- only whitespace, header style, and
table column padding. It leaves Unicode characters (em/en dashes, smart
quotes, checkmarks) as-is. Account-code-style hyphens are also preserved.

Usage:
    python3 apply_conventions.py input.md            # in-place
    python3 apply_conventions.py input.md output.md  # to new file

This script is idempotent: running it twice produces the same result as
running it once. Safe to re-run after manual edits.
"""

import re
import sys
import textwrap
from pathlib import Path


def apply_conventions(text: str) -> str:
    # ------------------------------------------------------------------
    # Step 1: Convert ATX H1/H2 to setext form.
    # ------------------------------------------------------------------
    def to_setext_h1(m):
        title = m.group(1).rstrip()
        return f"{title}\n{'=' * len(title)}"

    def to_setext_h2(m):
        title = m.group(1).rstrip()
        return f"{title}\n{'-' * len(title)}"

    text = re.sub(r"^# (.+)$", to_setext_h1, text, flags=re.MULTILINE)
    text = re.sub(r"^## (.+)$", to_setext_h2, text, flags=re.MULTILINE)

    # ------------------------------------------------------------------
    # Step 2: Convert ATX H3+ to symmetric form.
    # ------------------------------------------------------------------
    def symmetric_atx(m):
        hashes = m.group(1)
        title = m.group(2).strip()
        if title.endswith(hashes):
            return m.group(0)
        return f"{hashes} {title} {hashes}"

    text = re.sub(r"^(#{3,6}) (.+?)\s*#*\s*$", symmetric_atx, text,
                  flags=re.MULTILINE)

    # ------------------------------------------------------------------
    # Step 3: Header spacing -- BEFORE rule.
    # >=3 blank lines before H2; >=2 before H3+; exception first child.
    # ------------------------------------------------------------------
    lines = text.split("\n")

    def is_setext_h1_underline(line):
        return bool(line) and set(line.strip()) == {"="} and len(line.strip()) >= 2

    def is_setext_h2_underline(line):
        return bool(line) and set(line.strip()) == {"-"} and len(line.strip()) >= 2

    def is_atx_header_line(line):
        return bool(re.match(r"^#{3,6}\s", line))

    def get_atx_level(line):
        m = re.match(r"^(#{1,6})\s", line)
        return len(m.group(1)) if m else 0

    new_lines = []
    i = 0
    while i < len(lines):
        line = lines[i]

        header_level = 0
        if (i + 1 < len(lines) and is_setext_h1_underline(lines[i+1])
                and line.strip()):
            header_level = 1
        elif (i + 1 < len(lines) and is_setext_h2_underline(lines[i+1])
                and line.strip()):
            header_level = 2
        elif is_atx_header_line(line):
            header_level = get_atx_level(line)

        if header_level >= 2 and new_lines:
            n_blank = 0
            j = len(new_lines) - 1
            while j >= 0 and new_lines[j].strip() == "":
                n_blank += 1
                j -= 1
            prev_nonblank = new_lines[j] if j >= 0 else ""
            prev_is_setext_underline = (is_setext_h1_underline(prev_nonblank) or
                                         is_setext_h2_underline(prev_nonblank))
            prev_is_atx_header = is_atx_header_line(prev_nonblank)
            prev_is_header = prev_is_setext_underline or prev_is_atx_header

            if not prev_is_header:
                required = 3 if header_level == 2 else 2
                while new_lines and new_lines[-1].strip() == "":
                    new_lines.pop()
                new_lines.extend([""] * required)

        new_lines.append(line)
        i += 1
    text = "\n".join(new_lines)

    # ------------------------------------------------------------------
    # Step 4: Header spacing -- AFTER rule.
    # Exactly one blank line after every header.
    # ------------------------------------------------------------------
    lines = text.split("\n")
    new_lines = []
    i = 0
    while i < len(lines):
        line = lines[i]
        new_lines.append(line)

        is_header_end = False
        if is_atx_header_line(line):
            is_header_end = True
        elif (is_setext_h1_underline(line) or is_setext_h2_underline(line)) \
                and i > 0 and lines[i-1].strip():
            is_header_end = True

        if is_header_end and i + 1 < len(lines):
            j = i + 1
            while j < len(lines) and lines[j].strip() == "":
                j += 1
            if j < len(lines):
                new_lines.append("")
                i = j
                continue
        i += 1
    text = "\n".join(new_lines)

    # ------------------------------------------------------------------
    # Step 5: Align table column markers.
    # ------------------------------------------------------------------
    def is_table_row(line):
        return line.lstrip().startswith("|") and line.rstrip().endswith("|")

    def is_separator_row(line):
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if not cells:
            return False
        for c in cells:
            if not re.match(r"^:?-+:?$", c):
                return False
        return True

    def split_row(line):
        inner = line.strip()
        if inner.startswith("|"):
            inner = inner[1:]
        if inner.endswith("|"):
            inner = inner[:-1]
        return [c.strip() for c in inner.split("|")]

    def format_table(rows, separator_idx):
        n_cols = max(len(r) for r in rows)
        rows = [r + [""] * (n_cols - len(r)) for r in rows]
        widths = [0] * n_cols
        for idx, row in enumerate(rows):
            if idx == separator_idx:
                continue
            for j, cell in enumerate(row):
                if len(cell) > widths[j]:
                    widths[j] = len(cell)
        sep_row = rows[separator_idx]
        sep_aligns = []
        for j, cell in enumerate(sep_row):
            m = re.match(r"^(:?)-+(:?)$", cell)
            if m:
                sep_aligns.append((m.group(1), m.group(2)))
            else:
                sep_aligns.append(("", ""))
        out = []
        for idx, row in enumerate(rows):
            if idx == separator_idx:
                sep_cells = []
                for j, (left, right) in enumerate(sep_aligns):
                    w = max(widths[j], 3)
                    if (left, right) == (":", ":"):
                        c = ":" + "-" * (w - 2) + ":"
                    elif (left, right) == ("", ":"):
                        c = "-" * (w - 1) + ":"
                    elif (left, right) == (":", ""):
                        c = ":" + "-" * (w - 1)
                    else:
                        c = "-" * w
                    sep_cells.append(c)
                out.append("| " + " | ".join(sep_cells) + " |")
            else:
                cells = [row[j].ljust(widths[j]) for j in range(n_cols)]
                out.append("| " + " | ".join(cells) + " |")
        return out

    def align_tables(s):
        lines = s.split("\n")
        out = []
        i = 0
        while i < len(lines):
            if is_table_row(lines[i]):
                block_start = i
                while i < len(lines) and is_table_row(lines[i]):
                    i += 1
                block = lines[block_start:i]
                sep_idx = -1
                for j, b in enumerate(block):
                    if is_separator_row(b):
                        sep_idx = j
                        break
                if sep_idx == -1:
                    out.extend(block)
                else:
                    parsed = [split_row(r) for r in block]
                    formatted = format_table(parsed, sep_idx)
                    if any(len(line) > 150 for line in formatted):
                        out.extend(block)
                    else:
                        out.extend(formatted)
            else:
                out.append(lines[i])
                i += 1
        return "\n".join(out)

    text = align_tables(text)

    # ------------------------------------------------------------------
    # Step 6: Wrap prose at 80 chars; exceptions: code, table, headings,
    # blockquotes (with care), bullet items, lines with long URLs.
    # ------------------------------------------------------------------
    URL_RE = re.compile(r"https?://\S+")

    def wrap_paragraph_lines(para_lines, width=80):
        text_join = " ".join(line.strip() for line in para_lines)
        if not text_join.strip():
            return para_lines
        wrapped = textwrap.wrap(
            text_join, width=width,
            break_long_words=False,
            break_on_hyphens=False,
        )
        return wrapped

    def wrap_bullet_item(first_line, continuation_lines, width=80):
        m = re.match(r"^(\s*)([-*+]|\d+\.)\s+(.*)$", first_line)
        if not m:
            return [first_line] + continuation_lines
        leading_ws = m.group(1)
        marker = m.group(2)
        first_content = m.group(3)
        cont_indent = leading_ws + " " * (len(marker) + 1)
        all_content = first_content
        for line in continuation_lines:
            all_content += " " + line.strip()
        initial_indent = leading_ws + marker + " "
        wrapped = textwrap.wrap(
            all_content, width=width,
            initial_indent=initial_indent,
            subsequent_indent=cont_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        return wrapped or [first_line]

    def wrap_blockquote(bq_lines, width=80):
        stripped = [re.sub(r"^>\s?", "", l) for l in bq_lines]
        if any(re.match(r"^\s*\d+\.\s", s) for s in stripped):
            return bq_lines
        text_join = " ".join(s.strip() for s in stripped if s.strip())
        if not text_join.strip():
            return bq_lines
        wrapped = textwrap.wrap(
            text_join, width=width - 2,
            break_long_words=False,
            break_on_hyphens=False,
        )
        return [f"> {w}" for w in wrapped]

    def line_starts_table(line):
        return line.lstrip().startswith("|")

    def line_starts_code_fence(line):
        return line.strip().startswith("```")

    def line_is_setext_underline(line):
        s = line.strip()
        return s and (set(s) == {"="} or set(s) == {"-"}) and len(s) >= 2

    def line_is_atx_heading(line):
        return bool(re.match(r"^#+\s", line))

    def line_is_horizontal_rule(line):
        return line.strip() == "---" or line.strip() == "***"

    def line_is_blockquote(line):
        return line.lstrip().startswith(">")

    def line_is_bullet(line):
        return bool(re.match(r"^\s*([-*+]|\d+\.)\s", line))

    def manually_wrap_prose(s, width=80):
        lines = s.split("\n")
        out = []
        i = 0
        in_code_fence = False

        while i < len(lines):
            line = lines[i]

            if line_starts_code_fence(line):
                in_code_fence = not in_code_fence
                out.append(line)
                i += 1
                continue
            if in_code_fence:
                out.append(line)
                i += 1
                continue
            if line_starts_table(line):
                out.append(line)
                i += 1
                continue
            if line_is_setext_underline(line) or line_is_atx_heading(line):
                out.append(line)
                i += 1
                continue
            if line_is_horizontal_rule(line):
                out.append(line)
                i += 1
                continue
            if line.startswith("    ") and line.strip():
                out.append(line)
                i += 1
                continue
            if not line.strip():
                out.append(line)
                i += 1
                continue
            if line_is_bullet(line):
                first = line
                continuations = []
                j = i + 1
                m_first = re.match(r"^(\s*)([-*+]|\d+\.)\s", first)
                if m_first:
                    base_indent = len(m_first.group(1))
                    while j < len(lines):
                        next_line = lines[j]
                        if not next_line.strip():
                            break
                        if line_is_bullet(next_line):
                            break
                        if next_line.startswith(" " * (base_indent + 1)):
                            continuations.append(next_line)
                            j += 1
                        else:
                            break
                wrapped = wrap_bullet_item(first, continuations, width=width)
                out.extend(wrapped)
                i = j
                continue
            if line_is_blockquote(line):
                bq = [line]
                j = i + 1
                while j < len(lines) and line_is_blockquote(lines[j]):
                    bq.append(lines[j])
                    j += 1
                wrapped = wrap_blockquote(bq, width=width)
                out.extend(wrapped)
                i = j
                continue

            para = [line]
            j = i + 1
            while j < len(lines):
                nxt = lines[j]
                if not nxt.strip():
                    break
                if (line_starts_table(nxt) or
                    line_starts_code_fence(nxt) or
                    line_is_atx_heading(nxt) or
                    line_is_setext_underline(nxt) or
                    line_is_horizontal_rule(nxt) or
                    line_is_bullet(nxt) or
                    line_is_blockquote(nxt) or
                    nxt.startswith("    ")):
                    break
                para.append(nxt)
                j += 1
            wrapped = wrap_paragraph_lines(para, width=width)
            out.extend(wrapped)
            i = j

        return "\n".join(out)

    text = manually_wrap_prose(text, width=80)

    # Collapse runs of >4 blank lines
    text = re.sub(r"\n{5,}", "\n\n\n\n", text)

    if not text.endswith("\n"):
        text += "\n"

    return text


if __name__ == "__main__":
    inp = Path(sys.argv[1])
    outp = Path(sys.argv[2]) if len(sys.argv) > 2 else inp
    src = inp.read_text(encoding="utf-8")
    result = apply_conventions(src)
    outp.write_text(result, encoding="utf-8")

    long_lines = [(idx, ln) for idx, ln in enumerate(result.split("\n"), 1)
                  if len(ln) > 80]
    nonprose = [(n, ln) for n, ln in long_lines
                if ln.lstrip().startswith("|") or "http" in ln]
    prose_long = [(n, ln) for n, ln in long_lines
                  if not ln.lstrip().startswith("|") and "http" not in ln]
    print(f"Wrote {outp} ({len(result):,} chars, {len(result.splitlines())} lines)")
    print(f"Lines > 80 chars: {len(long_lines)}")
    print(f"  - tables/URLs (allowed): {len(nonprose)}")
    print(f"  - prose: {len(prose_long)}")
    if prose_long:
        for n, ln in prose_long[:5]:
            print(f"    line {n} ({len(ln)} chars): {ln[:80]}...")
