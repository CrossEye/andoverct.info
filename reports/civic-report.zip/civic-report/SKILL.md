---
name: civic-report
description: Create polished analytical reports for community/civic/municipal audiences from public data. Produces a markdown source with YAML front matter plus source-data files; the HTML and PDF are rendered from it by the site's local build engine in a consistent professional style (cream background, gold accents, section labels, green checkmarks on confirmed data, right-aligned numeric tables). Use whenever the user wants a report on town/school/regional budgets, public statistics, civic comparisons, school district data, municipal finances, or public-records analysis where the audience is residents/voters/community members and the output is a long-form analytical piece with tables, sources, and methodology — even if the user doesn't say "civic report" explicitly. Triggers include "build a report on X for the town", "do a budget analysis", "compare school districts", "write a public-facing analysis", "publish to my town website", or requests producing matched HTML+PDF with tables, citations, methodology.
---

# Civic Report

A skill for producing polished, well-sourced analytical reports for community
audiences. The reports are designed for residents, voters, and community
members reading municipal budgets, school district data, regional comparisons,
or similar civic information.

The primary deliverable is a **markdown source with YAML front matter** (the
build configuration) plus any source-data files. The matched HTML and PDF are
rendered from that markdown by the target site's local build engine
(`npm run report`). This split is deliberate: the writing and research — the
hard part — works well in any environment (including online research sessions),
and the deterministic HTML/PDF render happens at home with one command. You do
**not** need to render HTML or PDF here; focus on getting the markdown and front
matter right.

## When to use

This skill applies whenever:
- The audience is a community/civic/municipal one (residents, voters, parents,
  taxpayers, town meeting attendees)
- The data sources are publicly available (audits, budget documents, state
  databases, federal datasets, school district reports)
- The user wants matched HTML and PDF deliverables, not just a chat answer
- The report involves tables, sources, methodology, and analytical commentary

It does NOT apply for:
- Quick one-off answers that fit in a chat reply
- Reports for internal corporate audiences (use a corporate report style instead)
- Reports where the visual identity must match a different brand

## What this skill produces

A single folder containing:
- `report_name.md` — the markdown source: a **YAML front-matter block** (the
  build configuration — title, subtitle, attribution, footer, PDF page text,
  section labels, Other-Formats cards) followed by the report body, formatted to
  project conventions
- Any source data files (PDFs, spreadsheets, CSVs) referenced from the report

The HTML and PDF are **not** produced here. At home, the site's build engine
turns the markdown + front matter into:
- `index.html` — the rendered HTML (hover-reveal anchor links, click-to-zoom charts)
- `report_name.pdf` — the rendered PDF (page numbering, link annotations)

via:

```
npm run report -- reports/<section>/<slug>/report_name.md
```

All links inside the report are relative, so the folder can be moved to any
location on a web server without breaking. The engine reads `publicUrl` from the
front matter and passes it to WeasyPrint as the base URL, so PDF link
annotations resolve to production URLs rather than the build machine's
filesystem. See `references/build.md` for the front-matter schema.

## Workflow

The workflow has three phases: interview, draft, hand off. The render itself
(HTML + PDF) happens later, at home, by running the engine — it isn't part of
this skill's work.

### Phase 1: Interview

Ask the user the minimum set of questions needed to start drafting. See
`references/starter-questions.md` for the checklist. Default to "use your
best judgment" for anything the user doesn't have a strong opinion on.

The most important things to nail down before drafting — these populate the
front matter:
1. The report title and subtitle
2. The compilation date and the public web URL where the report will live
   (the `publicUrl`), plus which site `section` it's filed under
3. The data sources (what's already gathered, what still needs collecting)
4. Whether there are any "however" / counterbalancing arguments — see
   `references/structure.md` for the counterbalancing pattern

### Phase 2: Draft the markdown (with front matter)

Write the markdown source following the structure pattern in
`references/structure.md`. The file is:
- A **YAML front-matter block** carrying the build configuration (`title`,
  `subtitle`, `attribution`, `footer`, `pdf.author`/`pdf.footer`,
  `sectionLabels`, `formats`, and `publicUrl`/`section`). See
  `references/build.md` for the full field list, and `examples/sample_report.md`
  for a complete example.
- Then the body: H1 + methodology italic, Overview, body sections numbered
  `Part N — Title`, Summary table, Key Observations, What this report does not
  show, Sources, Other Formats.

The front matter carries the title/subtitle/attribution, so the body opens with
just the H1 and the methodology italic — not the old three-italic block.

Use the markdown conventions in `references/conventions.md`: setext H1/H2
underlines, symmetric ATX H3+, blank-line spacing rules, table column
alignment, prose wrapping at 80 chars.

For data tables, use ✓ on H3 headings to mark confirmed data sections (e.g.,
`### FY 2024-25 ✓ *Confirmed* ###`). For tables with notes, use blockquote
syntax (`> **Notes:** ...`) so the engine renders the gold-bordered Notes box.

Set the `formats` cards to exactly the formats that will exist — normally three
(HTML, Markdown, PDF). Naming the markdown `<slug>.md` makes the PDF default to
`<slug>.pdf`, so the PDF card's `href` is simply `<slug>.pdf`.

If you have the convention scripts available, run `scripts/apply_conventions.py`
after drafting to enforce formatting, then `scripts/fix_markdown.py` to insert
blank lines before bullet lists and tidy bare URLs. They operate on the body and
leave the front matter alone. They're optional polish — the engine renders
clean markdown fine without them.

### Phase 3: Hand off to the build engine

There is no per-report build script to edit anymore — the front matter **is**
the build configuration. The render happens at home with:

```
npm run report -- reports/<section>/<slug>/<report>.md
```

which writes `index.html` and `<report>.pdf` into the folder. (`npm run
report:all` rebuilds every report — handy after a shared CSS/engine change.) If
the report is new, it also needs an entry in the site's `reports/reports.json`
so it appears in the indexes; the report's `section` must match a key there.

When reviewing the result (or asking the user to), spot-check that:
- The methodology italic landed in the gold-bordered box; title/subtitle/
  attribution match the front matter
- Numeric table cells are right-aligned; ✓ markers are green
- The Other Formats cards link to files that exist (especially the PDF name)
- PDF link annotations point to web URLs, not `file://` paths

If the user publishes to a site that serves `.md` as plain text, remind them the
server's `.htaccess` (or equivalent) should set
`Content-Type: text/plain; charset=utf-8` for `.md` files, so the markdown
renders inline rather than downloading.

## Reference files

Read these as needed during the workflow:

- `references/starter-questions.md` — minimal interview checklist
- `references/structure.md` — report sections, ✓ confirmation markers, the
  optional counterbalancing/"however" pattern
- `references/conventions.md` — markdown formatting rules
- `references/build.md` — the front-matter schema the build engine reads

## Scripts

The HTML/PDF render is done at home by the site's build engine
(`npm run report`), not by a script bundled here. These optional Python helpers
polish the markdown body before hand-off:

- `scripts/apply_conventions.py` — applies markdown formatting conventions
  (setext headers, symmetric ATX, blank-line spacing, table alignment,
  prose wrapping). Run once after drafting.
- `scripts/fix_markdown.py` — inserts blank lines before bullet lists, and
  converts bare URLs to `[shortened-anchor](full-url)` form. Run after
  apply_conventions.py.

Both are safe to re-run (idempotent) and leave the YAML front matter untouched.

`scripts/build.py` is retained as a **legacy** standalone renderer (it predates
the shared engine and carries its own metadata block instead of reading front
matter). Prefer `npm run report`; reach for `build.py` only if you need a quick
self-contained preview in an environment without the site repo.

## Visual identity (opinionated)

The skill produces reports with a fixed visual identity. Don't try to
parameterize colors, fonts, or layout — the consistency is the point.
Past reports built with this skill share a visual family that readers come
to recognize. The look is owned by the build engine's theme (`bluegold` on
andoverct.info); if a future report genuinely needs a different look, that's a
theme on the engine side (front-matter `theme:` / a new theme file), not a
parameter of this skill.

The identity:
- Warm cream background (#fafaf7), dark text on cream
- Gold accent borders (#c8a85a) on the methodology box and Notes blockquotes
- Gray section labels (small uppercase) above each H2
- Dark blue links (#1d4e89), blue-700 on hover
- Green checkmarks (#2e7d32) on H3 headings marked as confirmed
- Right-aligned numeric table cells; left-aligned text
- Page banner at top of HTML linking back to the parent site
- Hover-reveal `¶` anchor link beside each H2/H3 in the HTML
- Print-specific CSS for clean PDF rendering with page numbers

## Common pitfalls

A few non-obvious failure modes. The reference files cover them, but worth
flagging up-front:

- **Missing front-matter fields** — the engine refuses to build without
  `publicUrl`, `pageTitle`, `title`, `subtitle`, `attribution`, `footer`, and
  `pdf.author`/`pdf.footer`. See `references/build.md` for the full list.
- **Dead PDF card** — the `formats` PDF `href` must match the generated PDF
  name. Naming the markdown `<slug>.md` makes the PDF default to `<slug>.pdf`,
  so set the card `href: <slug>.pdf`.
- **`file://` paths in the PDF** — keep in-document references to local files
  relative (bare filename); the engine resolves them against `publicUrl`.
- **Misaligned numeric table cells** — the engine right-aligns cells it
  recognizes as numeric (currency, %, signed/Unicode-minus, ranges, K/M,
  `$/unit`, approximate `~`). A misaligned column means a cell shape escaped the
  detector — normalize the cell text.
- **Bullet lists rendering as paragraphs** — markdown wants a blank line before
  the first bullet of a list; `scripts/fix_markdown.py` inserts these.
