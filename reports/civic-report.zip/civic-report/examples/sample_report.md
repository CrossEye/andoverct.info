---
section: budget
publicUrl: 'http://example.org/reports/library-funding/'
pageTitle: 'Sample Town Library Funding — Town of Sample, ST'
title: Sample Town Library Funding
subtitle: 'Town of Sample, ST · FY 2020–21 through FY 2024–25 · Five-year funding trajectory and peer comparison'
attribution: 'A personal report by Jane Author · <a href="mailto:jane@example.org">jane@example.org</a> · Not an official town document'
footer: 'Personal work of <a href="mailto:jane@example.org">Jane Author</a> · Compiled May 1, 2026<br>Data from the town''s annual audit reports and the State Public Library Statistics dataset. Not an official town document.'
pdf:
  author: Jane Author · jane@example.org
  footer: example.org/reports/library-funding/
sectionLabels:
  - - overview
    - Introduction
  - - part 1
    - Funding history
  - - summary table
    - At a glance
  - - sources
    - Documentation
  - - other formats
    - Download
formats:
  - icon: "\U0001F310"
    title: HTML
    href: ./
    desc: Interactive version with formatted tables; best for on-screen reading and sharing.
  - icon: "\U0001F4C4"
    title: Markdown
    href: sample_report.md
    desc: 'Plain-text version; readable in any editor, ideal for copying into other documents.'
  - icon: "\U0001F4D1"
    title: PDF
    href: sample_report.pdf
    desc: 'Print-ready version with all tables, footnotes, and source citations.'
---
Sample Town Library Funding
===========================

*Report compiled May 1, 2026, for use in town deliberations on the FY 2026–27
library budget. Data is drawn from the town's annual audit reports and the state
library's Public Library Statistics dataset. All figures are nominal dollars
unless otherwise noted; inflation-adjusted comparisons use CPI-U from the Bureau
of Labor Statistics.*

---



Overview
--------

The Sample Town Public Library serves a population of approximately 8,000
residents and operates as a department of the town government. Its budget is
voted on annually as part of the General Government section of the town budget.

This report answers two questions:

1. How has library funding changed in nominal and inflation-adjusted terms?
2. How does Sample compare to peer libraries in the region?


---



Part 1 — Five-year funding history
----------------------------------

### Annual budget figures ✓ *Confirmed from town audits* ###

| Fiscal Year | Library Budget | YoY Change |
| ----------- | -------------- | ---------- |
| 2020–21     | $245,000       | —          |
| 2021–22     | $251,000       | +2.4%      |
| 2022–23     | $263,500       | +5.0%      |
| 2023–24     | $271,400       | +3.0%      |
| 2024–25     | $278,800       | +2.7%      |

> **Notes:** Each year's figure is the approved budget at the annual town
> meeting, not the actual year-end expenditure. FY 2020–21 was unusually
> constrained by COVID-era cost containment. Source: Town of Sample Annual Audit
> Reports, FY 2020–21 through FY 2024–25.

The cumulative nominal increase from FY 2020–21 to FY 2024–25 was +13.8%.
Cumulative CPI-U inflation over the same period was approximately +18.4%, so the
library budget declined by roughly 4 percentage points in real terms.


---



Summary table
-------------

| Question                            | Answer                                                   |
| ----------------------------------- | -------------------------------------------------------- |
| What is the current library budget? | $278,800 (FY 2024–25 approved); roughly $35 per resident |
| How has it changed over five years? | +13.8% nominal; −4 pts in real terms versus CPI          |
| How does it compare to peer towns?  | Below the regional median of ~$42 per resident           |


---



Sources
-------

- Town of Sample Annual Audit Reports, FY 2020–21 through FY 2024–25
- Bureau of Labor Statistics CPI-U series, January 2020 through January 2026
- State Public Library Statistics Dataset, accessed at
  [statelib.example.gov/.../public-library-stats](https://statelib.example.gov/data/public-library-stats)


---



Other Formats
-------------

This report is available in three formats, all located alongside this file:

- **HTML** (interactive, best for on-screen reading): [`index.html`](index.html)
- **Markdown** (plain text, readable in any editor):
  [`sample_report.md`](sample_report.md)
- **PDF** (print-ready, fixed layout for distribution):
  [`sample_report.pdf`](sample_report.pdf)
