# Starter questions

When the user asks for a new civic report, run through this checklist
quickly. Default to "use your best judgment" for anything they don't have
a strong opinion on. Don't bombard them with all questions at once — group
related ones, and skip any answer the conversation has already provided.

## The minimum 4 questions

Ask these explicitly if they aren't already answered:

1. **What's the report about?** A single sentence. ("How AES preschool is
   funded." "Class sizes at RHAM compared to peer districts." "How
   Andover's town budget compares to inflation.")

2. **Where will it be published?** The full public URL of the folder where
   the report will live. This becomes the front-matter `publicUrl` — the base
   for PDF link annotations and the footer link. Format:
   `http://example.org/reports/topic/`. Also note which site `section` it's
   filed under (it must match a key in the site's `reports/reports.json`).

3. **What's the compilation date?** Today's date by default. The user may
   want to override (e.g., if they're updating an older report and want
   the original date preserved).

4. **What data sources do you have?** Even a partial list helps —
   it determines the methodology paragraph (the italic intro at the top of
   the report), and tells you whether to suggest gathering more sources
   before drafting.

## Optional questions

Ask these if relevant, but default to your best judgment:

- **Is there a "however" / counterbalancing argument?** The pattern is:
  "the headline number says X, *however* there's a structural reason Y
  that changes the picture." If so, plan for a dedicated section that
  walks through Y. See `structure.md` for the counterbalancing pattern.
- **Title and subtitle wording?** You can usually propose 2-3 options
  based on the topic and let the user pick. The title goes on the H1; the
  subtitle goes on a smaller line beneath, separated by `·` middle-dots.
- **Banner subtitle?** Shorter version that goes in the page banner at
  the top of the HTML view. Default: derive from the subtitle.
- **Number of Other Formats cards?** 3 (HTML/Markdown/PDF) is the default;
  use 4 if there's an Excel data file or other supporting deliverable.
- **Section labels for body H2s?** Each H2 in the body gets a small
  uppercase section label above it (e.g., "INTRODUCTION", "REVENUE",
  "ANALYSIS"). You can propose these based on the section headings; the
  user rarely needs to weigh in.

## Things to flag, not ask

These are setup details to mention briefly so the user knows what's
happening, but you don't need to wait for permission:

- The deliverable here is `report.md` (front matter + body) plus any source
  files; all links are relative. The HTML and PDF are generated at home by the
  site's build engine (`npm run report -- <md>`), which also needs a one-line
  entry in `reports/reports.json` for a brand-new report.
- The user will need an `.htaccess` (or equivalent) on their web server
  setting `Content-Type: text/plain; charset=utf-8` for `.md` files, so
  the markdown renders inline rather than downloading. Mention this once
  if you're not sure they already have it set up.
- The skill is opinionated about visual identity (cream background, gold
  accents, etc.). It's owned by the engine's theme; a different look is a
  theme change on the engine side, not something to parameterize here.

## After answering

Once you have the four required answers, draft the report skeleton (H1 +
italic blocks + section headings) and confirm with the user before
filling in the body. This is faster than asking 20 questions up front and
catches structural disagreements early.
