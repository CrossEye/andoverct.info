# Report structure

This reference describes the standard structure of a civic-report. The
structure is opinionated but not rigid — sections can be reordered or
omitted when the report doesn't need them, but the patterns within each
section should be followed.

## Front matter (top of the file)

Every report opens with a YAML front-matter block fenced by `---`. This is the
build configuration the engine reads — title, subtitle, attribution, footer,
PDF page text, section labels, and the Other-Formats cards all live here. See
`build.md` for the full field list. A minimal head:

```markdown
---
section: budget
publicUrl: 'http://andoverct.info/reports/budget/2026/'
pageTitle: 'Report Title — Town of Sample, ST'
title: Report Title Goes Here
subtitle: 'Town of Sample, ST · Time range · One-line description of what the report does'
attribution: 'A personal report by Author Name · <a href="mailto:author@email">author@email</a> · Not an official town document'
footer: 'Personal work of <a href="mailto:author@email">Author Name</a> · Compiled Month D, YYYY<br>Data from … . Not an official town document.'
pdf:
  author: Author Name · author@email
  footer: example.org/reports/budget/2026/
sectionLabels:
  - - overview
    - Introduction
formats:
  - { icon: "\U0001F310", title: HTML, href: ./, desc: 'Interactive version with formatted tables.' }
  - { icon: "\U0001F4C4", title: Markdown, href: report.md, desc: 'Plain-text version, readable in any editor.' }
  - { icon: "\U0001F4D1", title: PDF, href: report.pdf, desc: 'Print-ready version with all tables and citations.' }
---
```

## The opening (H1 + methodology italic)

Immediately after the front matter, the body opens with the H1 and the
methodology italic paragraph:

```markdown
Report Title Goes Here
======================

*Methodology paragraph in italics. Explains where the data came from, what time
periods it covers, what the reader can trust as definitive vs. estimated, and
any methodological choices that shaped the analysis. Run several sentences long.
The engine extracts this paragraph and renders it inside the gold-bordered
methodology box at the top of the published HTML and PDF.*
```

The H1 text and the attribution/subtitle now come from the **front matter**, not
the body — so the body needs only the H1 (which marks where prose begins) plus
the methodology italic. The engine's `splitReport()` step picks the longest
leading italic as the methodology header and discards any shorter leading
italics, so an extra attribution/subtitle italic left in the body is harmless
but unnecessary.

## Section sequence

Typical order, top to bottom:

1. **Overview** — orient the reader. Two or three short paragraphs.
   Sometimes a numbered list of the main components/parts.
2. **A note on methodology before the numbers** *(optional)* — if the
   report uses non-obvious methodology choices (e.g., marginal vs.
   average cost; teacher-eye vs. student-eye averaging), explain them
   here before showing the numbers.
3. **Body sections** — labeled `Part N — Title`. Each Part is one focused
   sub-analysis.
4. **Summary table** — a table that captures the headline answers in 5-10
   rows. Each row has a question and a one-sentence answer with caveats.
5. **Key Observations** — 4-8 short paragraphs, each starting with a
   bolded one-line claim. Reads like a list of "the things you should
   take away from this report."
6. **What this report does not show** — the caveats section. Honest about
   what's outside the report's scope or known to be uncertain.
7. **Sources** — the documentation. Bullets organized into logical
   subsections by source type (e.g., "Town budget documents", "State
   data sources").
8. **Other Formats** — pointers to the HTML/MD/PDF/Excel versions. The
   engine replaces this section's content with styled cards generated from
   the front-matter `formats` list.

## The ✓ confirmation marker convention

H3 headings on data sections can carry a confirmation marker:

```markdown
### FY 2024–25 ✓ *Confirmed* ###

### FY 2024–25 ✓ *Confirmed from audit, p.13* ###

### FY 2026–27 📋 *On the ballot — referendum May 5, 2026* ###
```

The convention:
- **✓** (U+2713) = data is confirmed from a primary source. The engine
  renders the ✓ in green.
- **📋** = data is proposed/on-the-ballot, not yet enacted. The text
  after explains the status.
- The italic text after the marker briefly cites the source or status.

The ✓ marker is the report's main trust signal. Use it generously
wherever data is directly verified from a primary source. For estimates
or inferences, omit the marker entirely.

## The Notes blockquote convention

Tables that need contextual explanation get a `> **Notes:**` blockquote
right below them:

```markdown
| Section | Amount |
|---------|--------|
| ...     | ...    |

> **Notes:** This is the only year in the series without a public
> referendum. Under Governor Lamont's COVID-19 executive order, the
> Board of Finance was authorized to set the budget directly...
> Source: Town of Andover FY 2020-21 Final Town Budget as of 5/27/2020.
```

The build renders the blockquote with a gold left border and a softer
background. Use Notes to:
- Explain methodology choices specific to that table
- Cite the primary source with date and document name
- Flag anomalies in the data
- Provide context that would clutter the table itself

## The "Part N" body section convention

Body sections are titled `Part 1 — Topic`, `Part 2 — Topic`, etc. (em-dash
between number and topic). The numbering is for cross-referencing —
later sections can say "as Part 3 showed..." and readers can find the
referenced material easily.

The em-dash (—) is intentional, not a hyphen. The build's typography
handles em-dashes correctly. Don't substitute hyphens.

## The counterbalancing / "however" pattern (optional)

Some reports have a structural counter-argument that changes the
headline interpretation. The pattern:

1. The opening section presents the narrow answer to the question
   ("the program costs $X")
2. A short pivot paragraph in the same section flags that the narrow
   answer is incomplete and forward-references the counterbalancing
   section ("...however, this misses Y; see Part N")
3. A dedicated body section walks through the counter-argument with its
   own data, methodology, and caveats
4. The summary table reflects both the narrow figure AND the
   counterbalanced figure, with a note pointing to the relevant section
5. Key Observations reflect the broader interpretation

This pattern is appropriate when:
- The narrow answer is mathematically correct but rhetorically misleading
- The counter-argument is structurally important (not just nuance)
- The data for the counter-argument is itself defensible from public sources

It's not appropriate when:
- The counter-argument is just hedging or "well, it depends"
- The data for the counter-argument is speculative
- It would obscure rather than clarify the reader's understanding

When using this pattern, present the narrow figure honestly first — don't
hide it. The counterbalancing section is a corrective layer, not a
replacement for the underlying analysis.

## Cross-references

Within the report, refer to body sections by their Part number:

```markdown
The financial argument in Part 4 is structural...
A more precise figure would require the data described in Part 5.
```

Don't use anchor links (`[Part 4](#part-4)`) in the markdown source — the
engine generates clickable anchor IDs automatically for HTML, but
the plain-text cross-reference works in any rendering of the markdown.

## Headings and casing

- **H1**: Title Case for the report title
- **H2 (`Part N — Topic`)**: Sentence case for the topic after the em-dash
- **H3**: Sentence case
- **Section labels** (rendered above each H2): the engine maps H2 text to
  short uppercase labels (e.g., "OVERVIEW", "REVENUE", "ANALYSIS") via the
  front-matter `sectionLabels` list — `[substring, label]` pairs, first match
  wins. See `build.md`.
