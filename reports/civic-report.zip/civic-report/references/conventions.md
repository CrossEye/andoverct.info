# Markdown conventions

These are the formatting conventions used in all reports built with this
skill. The script `scripts/apply_conventions.py` enforces all of them
automatically — running it after drafting will reformat the markdown to
match. The conventions are documented here so you can write the markdown
in close-to-final form on the first pass.

## 1. Setext headers for H1 and H2

Use `===` for H1 and `---` for H2, not `#` and `##`:

```markdown
Title of the Report
===================

Section Heading
---------------
```

The underline length should match the title length. The conventions
script normalizes this if it's off.

## 2. Symmetric ATX for H3 and below

H3+ uses the ATX form with closing hashes:

```markdown
### Subsection title ###

#### Sub-sub heading ####
```

Not `### Subsection title` (asymmetric) or `### Subsection title:` (no
trailing punctuation). The closing hashes are visual markers for editors
who scan for headings.

## 3. Blank line spacing around headers

The rules:
- **3 blank lines** before any H2 (unless it's the first child of the
  parent)
- **2 blank lines** before any H3+ (unless it's the first child)
- **1 blank line** after every header

The "first child" exception means: if an H3 immediately follows its
parent H2, only 1 blank line separates them (the after-header rule), not
2.

The conventions script enforces this automatically.

## 4. Indent nested bullets 2 spaces per level

```markdown
- Top-level item
  - Nested item (2 spaces of indent)
    - Doubly nested item (4 spaces)
- Another top-level item
```

## 5. Aligned table column markers

The conventions script aligns the column-marker row of every table:

```markdown
| Column 1     | Column 2 |
| ------------ | -------- |
| Cell content | Numbers  |
```

Not `| Column 1 | Column 2 |\n|---|---|` (the unaligned form). Tables wider
than 150 characters are left as-is — alignment for very wide tables can
make them harder to edit than help.

## 6. Prose wrapping at 80 characters

Wrap prose lines at 80 characters where possible. Exceptions:
- **Code blocks** — leave wrapping as-is
- **Table markup** — never wrap; tables span as wide as their data
- **Lines with unwrappable tokens** (e.g., long URLs that won't break) —
  leave the long line; better than splitting a URL

The conventions script handles wrapping automatically. After running it,
any line >80 chars should be one of the documented exceptions.

## 7. Blank lines before bullet lists

Markdown requires a blank line between a non-bullet line and the first
bullet of a list, otherwise the list renders as a paragraph:

```markdown
**Bold heading:**

- Bullet item one
- Bullet item two
```

NOT:

```markdown
**Bold heading:**
- Bullet item one          ← will render as paragraph!
- Bullet item two
```

The script `scripts/fix_markdown.py` handles this — only insert blank
lines before the *first* bullet of a list, not between sibling bullets.
The detection logic: if the previous non-blank line is itself a bullet
or a continuation of one (indented 2+ spaces), no blank line is needed;
otherwise insert one.

## 8. Bare URLs become markdown links

A raw URL renders as a long, ugly string (and in some renderers doesn't link at
all). Convert bare URLs to markdown links with friendly anchor text so they read
cleanly in both the HTML and the plain-text markdown:

```
https://hebronct.com/uploads/.../budget-book.pdf
```

becomes:

```markdown
[hebronct.com/.../budget-book.pdf](https://hebronct.com/uploads/.../budget-book.pdf)
```

The script `scripts/fix_markdown.py` handles this with a `shorten_url`
helper that produces `domain.com/.../last-segment` for paths with
multiple segments, or `domain.com/segment` for single-segment paths.
The full URL is preserved in the link target.

## 9. Use Unicode typography (not ASCII substitutes)

In running prose and table content, use:
- **em-dash** (—, U+2014) for sentence-level punctuation, NOT `--`
- **en-dash** (–, U+2013) for ranges (e.g., `2020–21`, `pages 1–10`),
  NOT `-`
- **smart quotes** (" " ' ', U+201C/D and U+2018/9), NOT `"` or `'`
- **Unicode minus** (−, U+2212) for negative numbers in tables, NOT `-`
- **middle dot** (·, U+00B7) as a separator in subtitles and footers,
  NOT `*` or `|`
- **checkmark** (✓, U+2713) for confirmed-data markers
- **clipboard** (📋, U+1F4CB) for proposed/on-the-ballot markers

These render correctly in HTML/PDF and look professional. ASCII
substitutes look amateurish next to professionally typeset documents.

The conventions script does NOT auto-convert ASCII to Unicode (too
risky — it would mangle code blocks and quoted material). Use Unicode
characters when writing the markdown.

## 10. Local document references are relative

Any local PDFs, spreadsheets, or other supporting documents that live in
the same folder as the report should be referenced with a bare filename:

```markdown
[FY 2024-25 audit](2025_AUDIT.pdf)
```

NOT:

```markdown
[FY 2024-25 audit](http://example.org/reports/topic/2025_AUDIT.pdf)
```

This keeps the report folder portable — it can be moved to a different
URL or a different server without breaking links. The engine resolves these
relative links against the front-matter `publicUrl` (WeasyPrint base URL) when
generating the PDF.

## Verification

After running both scripts, the markdown should pass these checks:
- Every H1/H2 uses setext form
- Every H3+ uses symmetric ATX (`### foo ###`)
- Every table column marker row is aligned (or the table is >150 chars wide)
- No prose lines exceed 80 chars (except code, tables, and lines with
  long URLs)
- Every bullet list has a blank line before its first item
- No bare `https://` or `http://` URLs outside markdown link syntax
- All local document references use bare filenames, not absolute URLs
