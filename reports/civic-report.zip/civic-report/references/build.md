# Front matter & build reference

Reports are now rendered by a shared build engine that lives in the target
site's repo (`_build/report.mjs`, run as `npm run report`). The engine reads
**YAML front matter** at the top of the report's markdown file and produces the
matched HTML and PDF from it — there is no longer a per-report `build.py` to
copy and edit.

The job of this skill, especially when authoring online, is to produce the
**markdown source with correct front matter** (plus any source-data files). The
HTML and PDF are generated locally, at home, by running the engine over that
markdown. You do not need to render HTML/PDF here.

```
npm run report -- reports/<section>/<slug>/<report>.md
```

That writes `index.html` and `<report>.pdf` into the same folder. (`npm run
report:all` rebuilds every report — useful after a shared CSS/engine change.)

This document describes the front-matter fields. The legacy `scripts/build.py`
is retained for an optional standalone preview, but the front matter below is
the canonical build configuration; keep it complete and correct.

## The front-matter block

The markdown file opens with a YAML block fenced by `---`. Everything that used
to live in `build.py`'s metadata block now lives here:

```yaml
---
section: 55th
publicUrl: 'http://andoverct.info/reports/55th/weir-position/'
pageTitle: 'Where Weir Sits in the House — CT 55th House District'
title: Where Weir Sits in the House
subtitle: "Connecticut's 55th House District · Voting record 2023–2026 · Where Rep. Steve Weir falls on the ideological spectrum of the House"
attribution: 'A personal report by Scott Sauyet · <a href="mailto:scott@sauyet.com">scott@sauyet.com</a> · Not an official town document'
footer: 'Personal work of <a href="mailto:scott@sauyet.com">Scott Sauyet</a> · Compiled June 11, 2026<br>Data from the Connecticut General Assembly and U.S. Census geography. Not an official town document.'
pdf:
  author: Personal work of Scott Sauyet · scott@sauyet.com
  footer: andoverct.info/reports/55th/weir-position/
sectionLabels:
  - - overview
    - Introduction
  - - part 1
    - Background
  - - summary table
    - At a glance
  - - sources
    - Documentation
  - - other formats
    - Download
formats:
  - icon: "\U0001F310"
    title: HTML
    href: ./
    desc: Interactive version with formatted tables; best for on-screen reading and sharing.
  - icon: "\U0001F4C4"
    title: Markdown
    href: <report>.md
    desc: 'Plain-text version; readable in any editor, ideal for copying into other documents.'
  - icon: "\U0001F4D1"
    title: PDF
    href: <report>.pdf
    desc: 'Print-ready version with all tables, footnotes, and source citations.'
---
```

### Required fields

The engine refuses to build if any of these are missing:

| Field         | Purpose |
| ------------- | ------- |
| `publicUrl`   | Public web URL of the folder, ending in `/`. Resolves PDF link annotations to web URLs and feeds the HTML footer link. |
| `pageTitle`   | Browser-tab title — usually `Title — Place/Context` form. |
| `title`       | The display H1 at the top of the report. |
| `subtitle`    | Subtitle line beneath the H1; `·` middle-dots separate clauses. |
| `attribution` | Attribution line beneath the subtitle. Inline HTML allowed (e.g. a `mailto:` link). |
| `footer`      | HTML-view footer below the content. Inline HTML and `<br>` allowed. |
| `pdf.author`  | Bottom-left text on every PDF page (keep ≈50 chars). |
| `pdf.footer`  | Bottom-right URL on every PDF page (no `http://` prefix). |

### Optional fields

| Field          | Purpose / default |
| -------------- | ----------------- |
| `section`      | Key into the site's `reports/reports.json` `sections` map; drives the breadcrumb (Home › Reports › Section › Title). Omit if the report isn't filed under a known section. |
| `sectionLabels`| List of `[substring, label]` pairs. Each H2 gets a small uppercase label above it; the **first** substring that matches the lowercased H2 text wins, so order specific → general. Use `''` as the label to suppress. |
| `formats`      | List of Other-Formats cards (`icon`, `title`, `href`, `desc`). The engine replaces the whole "Other Formats" section with styled cards and writes the matching "available in N formats" intro. List exactly the formats that will exist — typically HTML + Markdown + PDF (three). |
| `theme`        | Theme name; layered over `default.css`. Defaults to the site's configured theme (`bluegold` on andoverct.info). Omit unless the report needs a different look. |
| `htmlFile`     | Output HTML name. Default `index.html`. |
| `pdfFile`      | Output PDF name. Default is the markdown basename with `.pdf` — so naming the markdown `<slug>.md` yields `<slug>.pdf` automatically. |
| `extraCss`     | Filename of a report-specific CSS file in the folder, appended to the theme. |
| `plugin`       | Filename of a report-specific `.mjs` exporting `transform(html, ctx)`, run mid-pipeline. |
| `callouts`     | `true` wraps `➤ Update` paragraphs in a callout box. |
| `banner`       | `{left, right}` strings. Legacy/optional — the current engine builds the breadcrumb from `section` + `reports.json`, so `banner` is not required for new reports. |

## How the body relates to the front matter

The front matter supplies the **title, subtitle, and attribution** — so the
markdown body no longer needs them as italic lines. The body still opens with
the `# H1` (so the engine can find where the prose starts) followed by the
**methodology italic paragraph**; the engine extracts the longest leading
italic as the gold-bordered methodology header and discards any shorter leading
italics. See `structure.md`.

The PDF filename in the `formats` PDF card's `href` must match the actual PDF
name (the `pdfFile` value, or the markdown basename + `.pdf`). A mismatch leaves
a dead "PDF" link.

## Engine rendering behavior (unchanged from the old script)

The look and the table/typography handling carry over; you author the markdown
the same way. The engine still:

- Renders **✓** confirmation markers green on H3 headings.
- Right-aligns **numeric** table cells (currency, %, signed/Unicode-minus,
  ranges, K/M, `$/unit`, approximate `~`). If a column looks misaligned, a cell
  shape is escaping the numeric detector — fix the cell or report the shape.
- Renders `> **Notes:**` blockquotes as the gold-bordered Notes box.
- Adds hover-reveal `¶` header anchors (HTML only; hidden in print).
- Scales images to the column and makes them click-to-zoom in HTML (lightbox);
  the PDF keeps the scaled, static image.

## Common pitfalls

### `file://` paths in PDF link annotations

The engine sets the WeasyPrint base URL so links resolve to web URLs. Keep
in-document references to local files **relative** (bare filename), and the
absolute `publicUrl` does the rest. Hard-coding `file://` or build-machine
paths breaks this.

### Wrong PDF filename in the Other Formats card

The `formats` PDF `href` must equal the generated PDF name. Easiest path: name
the markdown `<slug>.md` and the PDF card `href: <slug>.pdf` — the default PDF
name then matches with no `pdfFile` override.

### Misaligned numeric table cells

A cell whose shape the numeric detector misses (an unusual marker, a stray
non-breaking space) won't right-align with its column. Normalize the cell text
rather than working around it.

### Stale self-URLs in the markdown

Don't hard-code the report's own absolute URL in the body (e.g. in intro prose).
Use relative links; `publicUrl` in the front matter is the single source of the
absolute location, so a moved report stays correct.
